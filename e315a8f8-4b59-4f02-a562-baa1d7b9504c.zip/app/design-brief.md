# Mess Near Me design brief
Design read: local diners need fast, trustworthy discovery; mess owners need simple control; administrators need a calm command center.
Concept spine: neighborhood wayfinding, making meal discovery feel like finding a dependable table nearby.
Delivery tier: cinema.
Palette: #F97316, #EA580C, #FFF7ED, #FFFFFF, #1F2937, #64748B. The requested orange identity is an explicit brand override.
Locked type: Outfit display, Inter Tight body, IBM Plex Mono metadata.
Animation mode: animated-website.
Journey shape: single-shot. One continuous table journey is the clearest discovery story.
Journey: establish a welcoming meal table, move into a weekly menu view, reveal plan durations, finish on an appetizing close.
World grammar: warm cream surfaces, natural daylight, restrained orange accents, local Kerala food atmosphere, tactile tabletop materials, steady forward camera.
Mobile framing: center-safe focal food arrangement with clear negative space.
Delivery budget: desktop <=32 MiB; mobile <=16 MiB.
Section plan: hero journey; city finder; featured messes; weekly menu; plan comparison; how it works; owner CTA; about/contact.
Asset plan: hero journey, food imagery, icon set, logo, favicon, OG card and film posters. Higgsfield visual generation is unavailable on the current account, so the site includes a lightweight local branded fallback film and vector share art rather than pretending generated media exists.
CTA inventory: Explore messes, View profile, Contact owner, Register your mess.
Functional scope: public discovery without customer registration, secure owner accounts, meal plans, Super Admin moderation, complaints, inquiries, advertising, city control, content, analytics, notifications, automation, audit and security. No AI, no online payments, no social feed.
