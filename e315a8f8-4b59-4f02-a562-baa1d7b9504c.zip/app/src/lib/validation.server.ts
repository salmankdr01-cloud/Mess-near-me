export function cleanText(v:unknown,max=5000){return String(v??'').trim().slice(0,max)}
export function requireText(v:unknown,field:string,max=5000){const s=cleanText(v,max);if(!s)throw new Error(`${field} is required`);return s}
export function validEmail(v:string){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)}
export function validPhone(v:string){return /^[+0-9()\-\s]{7,20}$/.test(v)}
