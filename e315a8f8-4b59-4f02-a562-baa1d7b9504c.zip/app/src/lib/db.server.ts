import {bindings} from './bindings.server';
export function requireDb(){const db=bindings().DB;if(!db)throw new Error('Database is not configured');return db}
export async function query<T=Record<string,unknown>>(sql:string,params:unknown[]=[]){return requireDb().prepare(sql).bind(...params).all<T>()}
export async function first<T=Record<string,unknown>>(sql:string,params:unknown[]=[]){return requireDb().prepare(sql).bind(...params).first<T>()}
