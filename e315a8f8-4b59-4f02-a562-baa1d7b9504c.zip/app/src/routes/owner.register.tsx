import { createFileRoute, Link } from '@tanstack/react-router';
import { useState } from 'react';

export const Route = createFileRoute('/owner/register')({ component: Register });

function Register() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    const form = event.currentTarget;
    const data = new FormData(form);
    const password = String(data.get('password') ?? '');
    const confirmation = String(data.get('confirm_password') ?? '');
    if (password.length < 8) { setError('Use a password with at least 8 characters.'); return; }
    if (password !== confirmation) { setError('Passwords do not match.'); return; }
    setBusy(true);
    try {
      const response = await fetch('/api/owner/register', { method: 'POST', body: data, headers: { accept: 'application/json' } });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.message || 'Unable to submit registration. Please check your details.');
      window.location.assign('/owner?registered=1');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to submit registration. Please try again.');
      setBusy(false);
    }
  }

  return <main className="mnm-auth-page mnm-auth-page-register">
    <Link className="mnm-logo" to="/">Mess <span>Near Me</span></Link>
    <div className="mnm-auth-card mnm-auth-card-wide">
      <div className="mnm-auth-mark" aria-hidden="true">M</div>
      <p className="mnm-eyebrow">MESS OWNER / REGISTRATION</p>
      <h1>Register your mess</h1>
      <p className="mnm-auth-intro">Create an owner account and submit your mess details. You can sign in to manage your profile and meal plans. Your listing will not appear publicly until it is reviewed and approved.</p>
      <form onSubmit={submit} encType="multipart/form-data">
        <div className="mnm-registration-group">
          <h2>1. Owner and business details</h2>
          <p>Enter the contact person and the mess information customers will use to find you.</p>
          <div className="mnm-form-grid">
            <label>Owner full name<input name="owner_name" autoComplete="name" placeholder="Your full name" maxLength={120} required /></label>
            <label>Mess / business name<input name="mess_name" autoComplete="organization" placeholder="Your mess name" maxLength={160} required /></label>
            <label>Email address<input name="email" type="email" autoComplete="email" placeholder="you@example.com" maxLength={160} required /></label>
            <label>Phone number<input name="phone" type="tel" autoComplete="tel" placeholder="+91 98765 43210" maxLength={30} required /></label>
            <label>WhatsApp number <span className="mnm-optional">Optional</span><input name="whatsapp" type="tel" placeholder="Leave blank if same as phone" maxLength={30} /></label>
            <label>City<input name="city" autoComplete="address-level2" placeholder="e.g. Kochi" maxLength={100} required /></label>
            <label className="mnm-wide">Full business address<textarea name="address" rows={3} autoComplete="street-address" placeholder="Building, street, locality and landmark" maxLength={500} required /></label>
            <label className="mnm-wide">About your mess <span className="mnm-optional">Optional</span><textarea name="description" rows={3} placeholder="Describe your meals, timings, facilities or service area" maxLength={3000} /></label>
          </div>
        </div>
        <div className="mnm-registration-group">
          <h2>2. Create your login</h2>
          <p>Use an email address you can access. Keep your password private.</p>
          <div className="mnm-form-grid">
            <label>Password<span className="mnm-password-wrap"><input name="password" type={showPassword ? 'text' : 'password'} autoComplete="new-password" minLength={8} maxLength={200} placeholder="At least 8 characters" required /><button type="button" className="mnm-password-toggle" onClick={() => setShowPassword(v => !v)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? 'Hide' : 'Show'}</button></span></label>
            <label>Confirm password<span className="mnm-password-wrap"><input name="confirm_password" type={showConfirmPassword ? 'text' : 'password'} autoComplete="new-password" minLength={8} maxLength={200} placeholder="Enter password again" required /><button type="button" className="mnm-password-toggle" onClick={() => setShowConfirmPassword(v => !v)} aria-label={showConfirmPassword ? 'Hide confirmation' : 'Show confirmation'}>{showConfirmPassword ? 'Hide' : 'Show'}</button></span></label>
          </div>
        </div>
        <div className="mnm-registration-group">
          <h2>3. Food safety details</h2>
          <p>FSSAI information is optional at registration. You may provide it now or submit it later for review.</p>
          <div className="mnm-form-grid">
            <label>FSSAI registration / license number <span className="mnm-optional">Optional</span><input name="fssai_number" maxLength={120} placeholder="Enter number, if available" /></label>
            <label>FSSAI certificate <span className="mnm-optional">Optional · PDF, JPG or PNG · up to 5 MB</span><input name="fssai_certificate" type="file" accept="application/pdf,image/jpeg,image/png,.pdf,.jpg,.jpeg,.png" /></label>
          </div>
        </div>
        <label className="mnm-checkbox"><input type="checkbox" name="terms" required /> I agree to the <Link to="/terms">Terms</Link> and <Link to="/privacy">Privacy Policy</Link>.</label>
        {error && <div className="mnm-auth-error" role="alert">{error}</div>}
        <button className="mnm-primary" type="submit" disabled={busy}>{busy ? 'Submitting registration…' : 'Submit registration'}</button>
        <p className="mnm-registration-note">After submitting, you will be taken to the sign-in page. Your account can be used to manage your mess, but public visibility depends on approval.</p>
      </form>
      <p className="mnm-auth-switch">Already registered? <Link to="/owner">Sign in</Link></p>
      <Link className="mnm-auth-back" to="/">← Back to discovery</Link>
    </div>
  </main>;
}
