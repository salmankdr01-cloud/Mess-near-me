import { createFileRoute, Link } from '@tanstack/react-router';
import { useState } from 'react';

export const Route = createFileRoute('/owner')({ component: OwnerLogin });

function OwnerLogin() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const registered = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('registered') === '1';

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError('');
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.message || 'Unable to sign in. Please try again.');
      window.location.assign(result.destination || '/owner/dashboard');
    } catch (err) { setError(err instanceof Error ? err.message : 'Unable to sign in. Please try again.'); setBusy(false); }
  }

  return <main className="mnm-auth-page">
    <Link className="mnm-logo" to="/">Mess <span>Near Me</span></Link>
    <div className="mnm-auth-card">
      <div className="mnm-auth-mark" aria-hidden="true">M</div>
      <p className="mnm-eyebrow">ACCOUNT ACCESS</p>
      <h1>Welcome back.</h1>
      <p className="mnm-auth-intro">Sign in to continue to your Mess Near Me workspace.</p>
      {registered && <div className="mnm-auth-success" role="status">Registration submitted. You can sign in after your account is approved.</div>}
      <form onSubmit={submit}>
        <label>Email address<input name="email" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required /></label>
        <label>Password<span className="mnm-password-wrap"><input name="password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" placeholder="Enter your password" value={password} onChange={e => setPassword(e.target.value)} required /><button type="button" className="mnm-password-toggle" onClick={() => setShowPassword(v => !v)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? 'Hide' : 'Show'}</button></span></label>
        {error && <div className="mnm-auth-error" role="alert">{error}</div>}
        <button className="mnm-primary" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
      <p className="mnm-auth-switch">New to Mess Near Me? <Link to="/owner/register">Register your mess</Link></p>
      <Link className="mnm-auth-back" to="/">← Back to discovery</Link>
    </div>
  </main>;
}
