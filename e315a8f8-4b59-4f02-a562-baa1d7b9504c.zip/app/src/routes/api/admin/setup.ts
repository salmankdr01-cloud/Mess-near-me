import { createFileRoute } from '@tanstack/react-router';
import { bindings } from '@/lib/bindings.server';
import { requireDb } from '@/lib/db.server';
import { hashPassword } from '@/lib/passwords.server';

export const Route = createFileRoute('/api/admin/setup')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const configured = bindings().MNMM_ADMIN_BOOTSTRAP_PASSWORD;
        if (!configured) {
          return new Response('Administrator bootstrap is not configured in this deployment.', { status: 503 });
        }
        const form = await request.formData();
        const email = String(form.get('email') ?? '').trim();
        const password = String(form.get('password') ?? '');
        if (!email || password !== configured) {
          return new Response('Bootstrap credential rejected.', { status: 403 });
        }
        const db = requireDb();
        const existing = await db.prepare("SELECT id FROM users WHERE role='super_admin'").first();
        if (existing) {
          return new Response('Super Admin already exists.', { status: 409 });
        }
        const now = new Date().toISOString();
        await db.prepare(`INSERT INTO users (id,name,email,password_hash,role,status,email_verified,must_change_password,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`)
          .bind(crypto.randomUUID(), 'Super Admin', email, await hashPassword(password), 'super_admin', 'active', 1, 1, now, now)
          .run();
        return new Response(null, { status: 303, headers: { Location: '/admin?setup=complete' } });
      },
    },
  },
});
