import { createFileRoute } from '@tanstack/react-router';
import { clearCookie } from '@/lib/auth.server';
export const Route=createFileRoute('/api/auth/logout')({server:{handlers:{POST:async()=>new Response(null,{status:303,headers:{Location:'/', 'Set-Cookie':clearCookie()}})}}});
