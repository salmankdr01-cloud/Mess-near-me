import { createFileRoute, Link } from '@tanstack/react-router';
import { useCallback, useEffect, useState } from 'react';

 type Overview = {
  user: { id: string; name: string; role: string } | null;
  stats?: { owners: number; plans: number; inquiries: number; complaints: number; cities: number; ads: number };
};

export const Route = createFileRoute('/admin/dashboard')({ component: AdminDashboard });

function AdminDashboard() {
  const [data, setData] = useState<Overview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch('/api/admin/overview', { headers: { accept: 'application/json' } });
      if (response.status === 401) {
        window.location.assign('/owner?next=%2Fadmin%2Fdashboard');
        return;
      }
      if (!response.ok) throw new Error('Could not load dashboard data. Please try again.');
      const result = await response.json() as Overview;
      if (!result.user) {
        window.location.assign('/owner?next=%2Fadmin%2Fdashboard');
        return;
      }
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Dashboard data is temporarily unavailable.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const stats = data?.stats;
  const cards = [
    { label: 'Mess owners', value: stats?.owners, detail: 'Registered owner profiles', icon: '01' },
    { label: 'Meal plans', value: stats?.plans, detail: 'Plans across the platform', icon: '02' },
    { label: 'Inquiries', value: stats?.inquiries, detail: 'Customer messages received', icon: '03' },
    { label: 'Open complaints', value: stats?.complaints, detail: 'Cases not yet closed', icon: '04' },
    { label: 'Cities', value: stats?.cities, detail: 'Active location records', icon: '05' },
    { label: 'Active ads', value: stats?.ads, detail: 'Currently active campaigns', icon: '06' },
  ];

  return <div className="mnm-control">
    <aside className="mnm-control-side">
      <Link className="mnm-logo" to="/">Mess <span>Near Me</span></Link>
      <div className="mnm-control-title">Platform workspace</div>
      <nav aria-label="Dashboard navigation">
        <a className="mnm-admin-nav-active" href="#overview">Overview</a>
        <a href="#operations">Operations</a>
        <Link to="/messes">Public listings</Link>
        <Link to="/owner">Account sign in</Link>
        <Link to="/">View website</Link>
      </nav>
      <form action="/api/auth/logout" method="post"><button className="mnm-control-logout" type="submit">Sign out</button></form>
    </aside>
    <main className="mnm-control-main">
      <header className="mnm-control-head" id="overview">
        <div><p className="mnm-eyebrow">MESS NEAR ME / OVERVIEW</p><h1>Platform overview</h1><p>Review current platform activity and open the available management areas.</p></div>
        <div className="mnm-admin-head-actions"><span className="mnm-admin-badge">Signed in{data?.user?.name ? ` · ${data.user.name}` : ''}</span><Link className="mnm-admin-primary-link" to="/owner/register">+ Register a mess</Link><button className="mnm-refresh-btn" onClick={() => void load()} disabled={loading}>{loading ? 'Refreshing…' : '↻ Refresh data'}</button></div>
      </header>
      {error && <div className="mnm-admin-error" role="alert"><span>{error}</span><button onClick={() => void load()}>Retry</button></div>}
      <section className="mnm-control-stats" aria-label="Live platform statistics">
        {cards.map(card => <article key={card.label}><div className="mnm-admin-stat-top"><small>{card.label}</small><span>{card.icon}</span></div><strong>{loading ? '—' : (card.value ?? 0).toLocaleString('en-IN')}</strong><p>{card.detail}</p></article>)}
      </section>
      <section className="mnm-admin-welcome"><div><p className="mnm-eyebrow">ADMINISTRATION</p><h2>Manage the platform with care.</h2><p>Dashboard totals are retrieved from the connected database. Use the public listing view to check what customers can currently see.</p></div><Link className="mnm-admin-primary-link" to="/messes">View public listings ↗</Link></section>
      <section className="mnm-control-grid mnm-admin-modules" id="operations">
        <article className="mnm-admin-registration"><div className="mnm-admin-module-icon">01</div><h2>Mess registration</h2><p>Open the registration form to add a mess owner, business details, contact information and optional FSSAI documents. New registrations require review before public listing.</p><Link className="mnm-admin-primary-link" to="/owner/register">Open mess registration →</Link></article>
        <article><div className="mnm-admin-module-icon">02</div><h2>Owner management</h2><p>Review owner accounts, registration status and submitted business information.</p><span className="mnm-module-status">Management screens not yet connected</span></article>
        <article><div className="mnm-admin-module-icon">03</div><h2>Meal plan moderation</h2><p>Review plans, publication eligibility and owner-submitted changes.</p><span className="mnm-module-status">Management screens not yet connected</span></article>
        <article><div className="mnm-admin-module-icon">04</div><h2>Inquiries and complaints</h2><p>Monitor customer contact requests and reported listing issues.</p><span className="mnm-module-status">Management screens not yet connected</span></article>
        <article><div className="mnm-admin-module-icon">05</div><h2>Advertising and cities</h2><p>View current campaign and location totals from the database.</p><span className="mnm-module-status">Management screens not yet connected</span></article>
        <article><div className="mnm-admin-module-icon">06</div><h2>Security and audit</h2><p>Administrative access is role-checked by the server. Detailed audit controls are not yet available.</p><span className="mnm-module-status">Advanced controls not yet connected</span></article>
        <article><div className="mnm-admin-module-icon">07</div><h2>System settings</h2><p>Production configuration and recovery controls depend on deployment setup.</p><span className="mnm-module-status">Settings screens not yet connected</span></article>
      </section>
      <p className="mnm-admin-footnote">Only the live overview metrics and navigation shown here are currently connected. Unavailable management modules are identified rather than presented as working controls.</p>
    </main>
  </div>;
}
